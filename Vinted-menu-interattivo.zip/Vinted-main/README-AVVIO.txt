VINTED BOT - AVVIO SU GITHUB ACTIONS

Il bot usa lo stesso schema del progetto Anti-doppioni: GitHub Actions avvia
un ciclo di ascolto Telegram di 420 secondi, salva lo stato e programma
automaticamente il ciclo successivo. Non serve un VPS.

CONFIGURAZIONE
1. Carica tutti i file di questa cartella nel repository GitHub.
2. In Settings > Secrets and variables > Actions crea il secret:
   VINTED_TELEGRAM_TOKEN = token del bot Telegram.
3. In Settings > Actions > General abilita i permessi di scrittura per
   GitHub Actions (Read and write permissions).
4. Avvia il workflow "Vinted" con Run workflow oppure attendi la pianificazione.

FUNZIONAMENTO
- Durante ogni ciclo (420 secondi) il bot resta in ascolto dei messaggi Telegram.
- I comandi vengono gestiti tramite long polling, con attesa massima di 20 secondi.
- Le ricerche Vinted vengono controllate subito e poi ogni 5 minuti.
- Alla fine salva vinted-stato.json e avvia il workflow successivo.
- Il comando /controlla forza un nuovo controllo.

FILTRO RECENSIONI
Quando aggiungi una ricerca, il bot chiede il numero minimo di recensioni
e la valutazione minima da 0 a 5 stelle. Scrivi 0 per disattivare ciascun filtro.

NOTA
GitHub Actions non è un processo permanentemente acceso: tra due esecuzioni
può esserci una breve pausa. Il sistema a catena replica il metodo usato
dal workflow Anti-doppioni.


MENU INTERATTIVO FILTRO VENDITORE
Quando aggiungi una ricerca, il bot mostra pulsanti Telegram per scegliere
il numero minimo di recensioni (nessun minimo, 1+, 5+, 10+, 20+, 50+, 100+)
e poi la valutazione minima (nessun minimo, 3, 3,5, 4, 4,5, 4,8 o 5 stelle).
Non devi digitare i valori: basta toccare i pulsanti nel messaggio del bot.
